(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[663],{3309:function(e,t,s){Promise.resolve().then(s.bind(s,238))},7461:function(e,t,s){"use strict";s.d(t,{Z:function(){return i}});var r=s(4090),n={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let s=(0,r.forwardRef)((s,i)=>{let{color:l="currentColor",size:o=24,strokeWidth:d=2,absoluteStrokeWidth:c,className:h="",children:u,...x}=s;return(0,r.createElement)("svg",{ref:i,...n,width:o,height:o,stroke:l,strokeWidth:c?24*Number(d)/Number(o):d,className:["lucide","lucide-".concat(a(e)),h].join(" "),...x},[...t.map(e=>{let[t,s]=e;return(0,r.createElement)(t,s)}),...Array.isArray(u)?u:[u]])});return s.displayName="".concat(e),s}},5032:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("Activity",[["path",{d:"M22 12h-4l-3 9L9 3l-3 9H2",key:"d5dnw9"}]])},8087:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("ArrowDownLeft",[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]])},8967:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]])},8442:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("FileCheck2",[["path",{d:"M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4",key:"1pf5j1"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m3 15 2 2 4-4",key:"1lhrkk"}]])},6615:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("Scale",[["path",{d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}],["path",{d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}]])},4059:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},2235:function(e,t,s){"use strict";s.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(7461).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},7907:function(e,t,s){"use strict";var r=s(5313);s.o(r,"usePathname")&&s.d(t,{usePathname:function(){return r.usePathname}}),s.o(r,"useRouter")&&s.d(t,{useRouter:function(){return r.useRouter}})},238:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return y}});var r=s(3827),n=s(4090),a=s(8792),i=s(7907),l=s(7461);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,l.Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);var d=s(4059),c=s(8087),h=s(8442),u=s(8967),x=s(6615),b=s(2235);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let m=(0,l.Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]),f=(0,l.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);var p=s(5032);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let w=(0,l.Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);function y(e){let{children:t,userName:s,userRole:l}=e,y=(0,i.usePathname)(),[k,v]=(0,n.useState)(!0),[g,j]=(0,n.useState)(!1),N=[{name:"Executive Overview",href:"/dashboard",icon:o},{name:"Client Parties Directory",href:"/dashboard/parties",icon:d.Z},{name:"Import Clearance (GD)",href:"/dashboard/imports",icon:c.Z},{name:"Analysis Certificates",href:"/dashboard/analysis",icon:h.Z},{name:"Export Shipping Bills",href:"/dashboard/exports",icon:u.Z},{name:"IOR Audit Engine",href:"/dashboard/reconciliation",icon:x.Z}];return(0,r.jsxs)("div",{className:"min-h-screen bg-slate-50 text-slate-900 font-sans flex selection:bg-blue-600 selection:text-white overflow-x-hidden relative",children:[g&&(0,r.jsx)("div",{onClick:()=>j(!1),className:"fixed inset-0 bg-black/70 backdrop-blur-sm z-40 md:hidden"}),(0,r.jsxs)("aside",{className:"fixed md:relative inset-y-0 left-0 bg-gradient-to-b from-blue-700 via-blue-900 to-slate-950 border-r border-blue-900 flex flex-col shrink-0 shadow-2xl z-50 transition-all duration-300 ease-in-out text-white ".concat(g?"translate-x-0 w-80":"-translate-x-full md:translate-x-0"," ").concat(k?"md:w-80":"md:w-20"),children:[(0,r.jsxs)("div",{className:"p-6 border-b border-blue-600/30 flex items-center justify-between",children:[(0,r.jsxs)("div",{className:"flex items-center gap-3.5 overflow-hidden ".concat(!k&&"md:justify-center md:w-full"),children:[(0,r.jsx)("div",{className:"w-12 h-12 bg-white text-blue-900 rounded-2xl flex items-center justify-center font-black text-2xl shadow-lg shrink-0",children:"CC"}),(k||g)&&(0,r.jsxs)("div",{className:"transition-opacity duration-200 truncate",children:[(0,r.jsx)("h1",{className:"text-lg font-black text-white tracking-wider uppercase flex items-center gap-1.5",children:"HASH ERP"}),(0,r.jsx)("p",{className:"text-xs font-semibold text-blue-200",children:"Customs & Freight Hub"})]})]}),(0,r.jsx)("button",{onClick:()=>j(!1),className:"md:hidden p-1.5 rounded-xl bg-blue-900 text-blue-200 hover:text-white",children:(0,r.jsx)(b.Z,{className:"w-6 h-6"})}),(0,r.jsx)("button",{onClick:()=>v(!k),className:"hidden md:flex p-2 rounded-xl bg-blue-900/80 text-blue-200 hover:text-white hover:bg-blue-800 transition shadow-md border border-blue-600/30 shrink-0 cursor-pointer ".concat(!k&&"absolute -right-3.5 top-6 z-30 bg-blue-800"),title:k?"Collapse Sidebar":"Expand Sidebar",children:k?(0,r.jsx)(m,{className:"w-5 h-5"}):(0,r.jsx)(f,{className:"w-5 h-5"})})]}),(0,r.jsxs)("nav",{className:"flex-1 p-4 space-y-2.5 overflow-y-auto mt-2",children:[(k||g)&&(0,r.jsx)("div",{className:"px-3 py-2 text-xs font-black text-blue-300 uppercase tracking-widest",children:"Core Modules"}),N.map(e=>{let t=e.icon,s=y===e.href||"/dashboard"!==e.href&&y.startsWith(e.href);return(0,r.jsxs)(a.default,{href:e.href,onClick:()=>j(!1),className:"group relative flex items-center justify-between px-4 py-4 rounded-xl text-base font-bold transition-all duration-200 ".concat(s?"bg-white text-blue-950 shadow-xl shadow-black/20":"text-blue-100 hover:bg-blue-800/60 hover:text-white"),title:k?void 0:e.name,children:[(0,r.jsxs)("div",{className:"flex items-center gap-4 ".concat(!k&&"md:justify-center md:w-full"),children:[(0,r.jsx)(t,{className:"w-6 h-6 shrink-0 transition-transform duration-200 group-hover:scale-110 ".concat(s?"text-blue-700":"text-blue-300 group-hover:text-white")}),(k||g)&&(0,r.jsx)("span",{className:"truncate",children:e.name})]}),(k||g)&&s&&(0,r.jsx)(f,{className:"w-5 h-5 text-blue-700 shrink-0"}),!k&&(0,r.jsx)("div",{className:"hidden md:group-hover:block absolute left-full ml-3 px-3 py-1.5 bg-slate-900 border border-slate-700 text-white text-xs rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition whitespace-nowrap z-50",children:e.name})]},e.name)})]}),k||g?(0,r.jsxs)("div",{className:"p-4 m-4 bg-blue-950/60 border border-blue-600/30 rounded-xl space-y-2",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between text-xs",children:[(0,r.jsxs)("span",{className:"font-bold text-blue-200 flex items-center gap-2 text-sm",children:[(0,r.jsx)(p.Z,{className:"w-4 h-4 text-cyan-400 animate-pulse"})," WeBOC Portal"]}),(0,r.jsx)("span",{className:"text-xs font-black text-cyan-200 bg-blue-900/80 border border-blue-500 px-2.5 py-0.5 rounded-full",children:"LIVE"})]}),(0,r.jsx)("p",{className:"text-xs font-semibold text-blue-300",children:"IOCO Matrix API Engine Online"})]}):(0,r.jsx)("div",{className:"hidden md:flex justify-center py-4",title:"WeBOC Portal Live",children:(0,r.jsx)("span",{className:"w-4 h-4 rounded-full bg-cyan-400 animate-pulse block shadow-md"})})]}),(0,r.jsxs)("div",{className:"flex-1 flex flex-col min-w-0 bg-slate-50 overflow-hidden",children:[(0,r.jsxs)("div",{className:"md:hidden h-14 bg-blue-900 text-white border-b border-blue-800 px-4 flex items-center justify-between shrink-0 z-30 shadow-sm",children:[(0,r.jsx)("button",{onClick:()=>j(!0),className:"p-2 rounded-xl bg-blue-800 text-white hover:bg-blue-700 transition cursor-pointer",title:"Open Menu",children:(0,r.jsx)(w,{className:"w-6 h-6"})}),(0,r.jsx)("span",{className:"text-base font-bold text-white",children:"HASH ERP Command"}),(0,r.jsx)("div",{className:"w-6"})]}),(0,r.jsx)("main",{className:"flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50",children:t})]})]})}}},function(e){e.O(0,[792,971,69,744],function(){return e(e.s=3309)}),_N_E=e.O()}]);